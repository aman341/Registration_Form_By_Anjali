function printError(Id, Msg) {
    document.getElementById(Id).innerHTML = Msg;
}

function validateForm() {
    // Input values
    var name = document.Form.name.value.trim();
    var email = document.Form.email.value.trim();
    var mobile = document.Form.mobile.value.trim();
    var state = document.Form.state.value.trim();
    var course = document.Form.course.value.trim();

    // Error states
    var nameErr = emailErr = mobileErr = stateErr = courseErr = true;

    // Validate Name
    if (name === "") {
        printError("nameErr", "Please enter your name");
        setErrorStyle("name");
    } else if (!/^[a-zA-Z\s]+$/.test(name)) {
        printError("nameErr", "Please enter a valid name");
        setErrorStyle("name");
    } else {
        printError("nameErr", "");
        nameErr = false;
        setSuccessStyle("name");
    }

    // Validate Email
    if (email === "") {
        printError("emailErr", "Please enter your email address");
        setErrorStyle("email");
    } else if (!/^\S+@\S+\.\S+$/.test(email)) {
        printError("emailErr", "Please enter a valid email address");
        setErrorStyle("email");
    } else {
        printError("emailErr", "");
        emailErr = false;
        setSuccessStyle("email");
    }

    // Validate Mobile
    if (mobile === "") {
        printError("mobileErr", "Please enter your mobile number");
        setErrorStyle("mobile");
    } else if (!/^[1-9]\d{9}$/.test(mobile)) {
        printError("mobileErr", "Please enter a valid 10-digit mobile number");
        setErrorStyle("mobile");
    } else {
        printError("mobileErr", "");
        mobileErr = false;
        setSuccessStyle("mobile");
    }

    // Validate State
    if (state === "") {
        printError("stateErr", "Please enter your state");
        setErrorStyle("state");
    } else if (!/^[a-zA-Z\s]+$/.test(state)) {
        printError("stateErr", "Please enter a valid state");
        setErrorStyle("state");
    } else {
        printError("stateErr", "");
        stateErr = false;
        setSuccessStyle("state");
    }

    // Validate Course
    if (course === "") {
        printError("courseErr", "Please enter your course");
        setErrorStyle("course");
    } else if (!/^[a-zA-Z\s]+$/.test(course)) {
        printError("courseErr", "Please enter a valid course");
        setErrorStyle("course");
    } else {
        printError("courseErr", "");
        courseErr = false;
        setSuccessStyle("course");
    }

    // Prevent form submission if there are errors
    return !(nameErr || emailErr || mobileErr || stateErr || courseErr);
}

function setErrorStyle(id) {
    document.getElementById(id).classList.add("input-2");
    document.getElementById(id).classList.remove("input-1");
}

function setSuccessStyle(id) {
    document.getElementById(id).classList.add("input-1");
    document.getElementById(id).classList.remove("input-2");
}